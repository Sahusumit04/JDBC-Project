package models;

import java.sql.*;

public class Product {
    private Integer productId;
    private String productName;
    private Date productionDate;
    private String companyName;
    private Integer price;
    private Integer quantity;
    private Float discount;

    public Product(String productName, String companyName, Integer price, Integer quantity, Float discount, Date productionDate) {
        this.productName = productName;
        this.companyName = companyName;
        this.price = price;
        this.quantity = quantity;
        this.discount = discount;
        this.productionDate = productionDate;
    }

    public void saveProductInfo() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/productsdb?user=root&password=1234");

            String query = "insert into products (product_name, company_name, price, quantity, discount, production_date) value (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, productName);
            ps.setString(2, companyName);
            ps.setInt(3, price);
            ps.setInt(4, quantity);
            ps.setFloat(5, discount);
            ps.setDate(6, productionDate);

            ps.executeUpdate();

            con.close();
        } catch(SQLException|ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public Date getProductionDate() {
        return productionDate;
    }
    public void setProductionDate(Date productionDate) {
        this.productionDate = productionDate;
    }
    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public Integer getPrice() {
        return price;
    }
    public void setPrice(Integer price) {
        this.price = price;
    }
    public Integer getQuantity() {
        return quantity;
    }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    public Float getDiscount() {
        return discount;
    }
    public void setDiscount(Float discount) {
        this.discount = discount;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }
}
